使用方法：解压后命令行切换到目录下执行`ant run` 运行程序，执行`ant test` 运行 junit 测试，直接执行`sonar-runner` 运行 sonar 分析.

`ImplementImageIO.java`,  `ImplementImageProcessor.java` 位于`src/imager` 下，`ImageProcessorTest.java` 位于 `src/test/imager` 下