解压后命令行切换到文件夹下执行`ant run` 即可运行。执行`sonar-runner` 即可运行 sonar 分析。



`MazeBug.java` 位于`projects/mazeBug/info/gridworld/maze` 下